from tkinter import *
from PIL import  ImageTk,ImageTk
import sqlite3

root = Tk()
root.title('Shashi Group')


#database

conn = sqlite3.connect('book.db')

c= conn.cursor()

'''c.execute("""CREATE TABLE addresses (
        name text,
        age integer,
        city text
        )""")'''
#create submit function 
def submit():
    conn = sqlite3.connect('book.db')

    c= conn.cursor()

    #insert into table
    c.execute("INSERT INTO addresses VALUES (:name, :age, :city)",
                 {
                    'name': name.get(),
                    'age' : age.get(),
                    'city' : city.get()
                 })
    conn.commit()

    conn.close()

    name.delete(0,END)
    age.delete(0,END)
    city.delete(0,END)

#create text box
name = Entry(root, width=30)
name.grid(row=0, column=1 , padx=20)

age= Entry(root, width=30)
age.grid(row=1, column=1)

city = Entry(root, width=30)
city.grid(row=2, column=1 )
 
#create text box label

name_label = Label(root , text= "Name:-")
name_label.grid(row=0, column=0)

age_label = Label(root , text= "Age:-")
age_label.grid(row=1, column=0)

city_label = Label(root , text= "City:-")
city_label.grid(row=2, column=0)

#create buttons
submit_btn = Button(root, text ="Add to Record", command=submit)
submit_btn.grid(row=3, column=0, columnspan=2, padx=10, pady=10, ipadx=100)

conn.commit()

conn.close()

root.mainloop()