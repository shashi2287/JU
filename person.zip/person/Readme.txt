I have created a database interface application for a person having his name, age and city as attributes using SQLite in python
At first an empty table is created then we enter the details of the person.
The book.db file has all the details of the example person schema.
The db file can be executed in Oracle software by runnning this command ("SELECT * FROM addresses;").